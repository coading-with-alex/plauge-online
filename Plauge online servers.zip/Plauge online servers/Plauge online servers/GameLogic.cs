﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Plauge_online_servers
{
    class GameLogic
    {
        public static void Update()
        {
            ThreadManager.UpdateMain();
        }
    }
}
